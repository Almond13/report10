const express = require('express');
const app = express();

//EJS 사용
app.set('view engine','ejs');
// mongoDB사용
const MongoClient = require('mongodb').MongoClient;
// body-parser 사용
app.use(express.urlencoded({extended:true}));
app.use(express.json());
// method-override 사용
const methodOverride = require('method-override')
app.use(methodOverride('_method'));


let bookDBUrl='mongodb+srv://admin:qwer1234@cluster0.lzp2a.mongodb.net/bookDB?retryWrites=true&w=majority';
let bookAppDB;

MongoClient.connect(bookDBUrl,(err,result)=>{
    if(err) return console.log('도서 조회 실패');
    bookAppDB = result.db('bookDB');

    app.listen(8080,()=>{
        console.log('도서 조회 성공');    
    })
})

app.get('/write',(req,res)=>{
    res.render('write.ejs')
  })

//도서조회페이지
app.get('/',(req,res)=>{
    bookAppDB.collection('bookmanager').find().toArray((err,result)=>{
        if(err) return console.log('자료검색오류');
        res.render('search.ejs',{bookData:result});
        console.log(result);
    })   
})


//도서등록

app.post('/add',(req,res)=>{
    let appTitle = req.body.title;
    let appSerial = parseInt(req.body.serial);  

    bookAppDB.collection('bookcount').findOne({도서갯수:'도서갯수'},(err,result)=>{
      if(err) return console.log('도서갯수조회 실패');    
      let totalCount = result.전체도서갯수;

      bookAppDB.collection('bookmanager').insertOne({title:appTitle,serial:appSerial,_id:totalCount+1},(err,result)=>{
        if(err) return console.log('/add 오류');
        console.log('/add 성공');
        bookAppDB.collection('bookcount').updateOne({도서갯수:'도서갯수'},{$inc:{전체도서갯수:1}},(err,result)=>{
          if(err) return console.log('/add 문서갯수 변경오류');
          res.redirect('/');
        })
      })
    });  
  })

//삭제하기
app.delete('/delete', (req, res) => {
    req.body._id=parseInt(req.body._id)
    bookAppDB.collection('bookmanager').deleteOne({_id:req.body._id},(err,result)=>{
    if(err) return console.log('삭제오류');
    console.log(typeof req.body._id)
    res.status(200)
    })  
})